function Propanotemcorr(pic,part)
leftPic = pic;
rightPic = part;
pic = rgb2gray(pic);
part = rgb2gray(part);
pic = double(pic);
[z1,z2,z3] = size(part);
part = double(part(:,1:(0.1*z2),:));
[x1,y1] = size(pic);
[x2,y2] = size(part);
MeanPart = mean(mean(part));
diff = zeros(x1,y1);
for i=1:x1-x2+1
    for j=1:y1-y2+1
        SubIm = pic(i:i+x2-1,j:j+y2-1);
        MeanSub = mean(mean(SubIm));
        top =0;
        down1 =0;
        down2 =0;
        for a=1:x2
            for b=1:y2
                top = top + ((SubIm(a,b)-MeanSub)*(part(a,b)-MeanPart));
                down1 = down1 +  power((part(a,b)-MeanPart),2);
                down2 = down2 +  power((SubIm(a,b)-MeanSub),2);
            end
        end
        down = down1*down2;
        diff(i,j) = top/(power(down,0.5));
    end
end
newpic = leftPic;
for i=1:x1
    for j=1:y1
        if abs(diff(i,j)) == max(max(abs(diff)))
            newpic(i:i+x1-1,j:j+y1-1,:) = rightPic;
            point = i;
        end
        
    end
end
subplot(2,2,1);
imshow(uint8(leftPic));
title('First image');
subplot(2,2,2);
imshow(uint8(rightPic));
title('Second image');
subplot(2,2,3);
imshow(uint8(newpic));
title('Panorama image');