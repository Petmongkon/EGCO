pic = imread('cameraman.tif');
part = imread('template.bmp');
figure();
Mytemcorr(pic,part);
p1 = imread('P1.bmp');
p2 = imread('P2.bmp');
figure();
Propanotemcorr(p1,p2);