function Mytemcorr(pic,part)
pic = double(pic);
part = double(part);
[x1,y1] = size(pic);
[x2,y2] = size(part);
diff = ones(x1,y1);
for i=x2:x1-x2
    for j=y2:y1-y2
        diff(i,j) = sum(sum(abs(pic(i:i+x2-1,j:j+y2-1)-part)));
    end
end
newpic = pic;
for i=1:x1
    for j=1:y1
        if diff(i,j) == 0
            newpic(i:i+x2-1,j) = 255;
            newpic(i:i+x2-1,j+y2-1) = 255;
            newpic(i,j:j+y2-1) = 255;
            newpic(i+x2-1,j:j+y2-1) = 255;
        end
        
    end
end
subplot(2,2,1);
imshow(uint8(pic));
title('Original image');
subplot(2,2,2);
imshow(uint8(part));
title('Template image');
subplot(2,2,3);
imshow(uint8(newpic));
title('Matching result using correlation');